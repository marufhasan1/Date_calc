﻿Public Class Form1
    Public my_date As New Date_calc.Date_calc
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = my_date.date_diff("01/08/2014", "10/05/2017")
        'Dim the_date As Date = my_date.date_filter("2017/12/01")
        'Label1.Text = the_date
    End Sub
End Class
